package com.example.lapitapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {
EditText led1,led2;
Button b1;
FirebaseAuth mAuth;
private ProgressDialog mloginprogress;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        led1=findViewById(R.id.le1);
        led2=findViewById(R.id.le2);
        b1=findViewById(R.id.lb1);
        mAuth=FirebaseAuth.getInstance();
        mloginprogress=new ProgressDialog(this);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email=led1.getText().toString().trim();
                String password=led2.getText().toString().trim();
                if (!TextUtils.isEmpty(email)|| !TextUtils.isEmpty(password))
                {
                    mloginprogress.setTitle("Logging In");
                    mloginprogress.setMessage("please wait while we create");
                    mloginprogress.setCanceledOnTouchOutside(false);
                loginuser(email,password);
                }
            }
        });
    }

    private void loginuser(String email, String password) {

        mAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful())
                {
                    mloginprogress.dismiss();
                    Intent mainIntent=new Intent(LoginActivity.this,MainActivity.class);
                    mainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK |Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(mainIntent);
                    finish();
                }
                else {
                    mloginprogress.hide();
                    Toast.makeText(getApplicationContext(),"Error",Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
