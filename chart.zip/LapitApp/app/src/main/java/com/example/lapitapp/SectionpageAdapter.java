package com.example.lapitapp;

import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

class SectionpageAdapter extends FragmentPagerAdapter {
    public SectionpageAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        switch (position)
        {
            case 0:
                RequestFregment requestFregment=new RequestFregment();
                return requestFregment;
            case 1:
                ChartsFregment chartsFregment=new ChartsFregment();
                return chartsFregment;
            case 2:
                FriendsFregment friendsFregment=new FriendsFregment();
                return friendsFregment;
                default:
                    return null;
        }
    }

    @Override
    public int getCount() {
        return 3;

    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        switch (position)
        {
            case 0:
                return "REQUEST";
            case 1:
                return "CHARTS";
            case 2:
                return "FRIENDS";
                default:
                    return null;
        }
    }
}
